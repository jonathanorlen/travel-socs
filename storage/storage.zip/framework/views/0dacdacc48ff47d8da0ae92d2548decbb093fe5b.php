<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html">Stisla</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">St</a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Home Menu</li>
            <li><a class="nav-link" href="<?php echo e(route('city')); ?>"><i class="far fa-user"></i> <span>City</span></a></li>
            <li><a class="nav-link" href="<?php echo e(route('place')); ?>"><i class="far fa-user"></i> <span>Place</span></a></li>
            <li><a class="nav-link" href="<?php echo e(route('agent')); ?>"><i class="far fa-user"></i> <span>Agent</span></a></li>
        </ul>
    </aside>
</div><?php /**PATH E:\BINUS\Semester 5\web programming\laravel-project\travel\resources\views/backend/includes/sidebar.blade.php ENDPATH**/ ?>