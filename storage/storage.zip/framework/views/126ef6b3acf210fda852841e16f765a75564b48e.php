  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo e(url('assets/modules/bootstrap/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('assets/modules/fontawesome/css/all.min.css')); ?>">

  <!-- CSS Libraries -->
  <link rel="stylesheet" href="<?php echo e(url('assets/modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('assets/css/components.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(url('assets/modules/summernote/summernote-bs4.css')); ?>"><?php /**PATH E:\BINUS\Semester 5\web programming\laravel-project\travel\resources\views/backend/includes/styles.blade.php ENDPATH**/ ?>