
<?php $__env->startSection('content'); ?>
<main>
    <style>
        .hero_in.contacts:before {
            background: url(<?php echo e(url('images/agent/'.$data->image)); ?>)
        }
    </style>
     <section class="hero_in contacts">
         <div class="wrapper">
             <div c lass="container">
                 <h1 class="fadeInUp"><span></span>Kencana Tour Travel Agent</h1>
             </div>
         </div>
     </section>
     <!--/hero_in-->

     <div class="contact_info">
         <div class="container">
             <ul class="clearfix">
                 <li>
                     <i class="pe-7s-map-marker"></i>
                     <h4>Address</h4>
                     <span><?php echo e($data->address); ?></span>
                 </li>
                 <li>
                     <i class="pe-7s-mail-open-file"></i>
                     <h4>Email address</h4>
                     <span><?php echo e($data->email); ?></span>

                 </li>
                 <li>
                     <i class="pe-7s-phone"></i>
                     <h4>Contacts info</h4>
                     <span><?php echo e($data->phone); ?> (WA)</span>
                 </li>
             </ul>
         </div>
     </div>
     <!--/contact_info-->
     <!--/main-->

     <div class="container margin_60_35">
         <div class="row">
             <div class="col-lg-12">
                 <article class="blog wow fadeIn">
                     <div class="row no-gutters">
                         <div class="col-lg-6">
                             <figure>
                                 <img src="<?php echo e(url('images/agent/'.$data->profile)); ?>" alt="">
                             </figure>
                         </div>
                         <div class="col-lg-6">
                             <div class="post_info">
                                 
                                 <h3><a href="blog-post.html">Kencana Agent</a></h3>
                                 <?php echo e($data->description); ?>

                                 <ul>
                                     <li>
                                         <div class="thumb"><img src="img/thumb_blog.jpg" alt=""></div>Michael Valdio
                                     </li>
                                     <li><i class=""></i> <?php echo e($data->owner); ?></li>
                                 </ul>
                             </div>
                         </div>
                     </div>
                 </article>
                 <!-- /article -->
             </div>


             

             <!-- /aside -->
         </div>
         <!-- /row -->
     </div>



     <div class="detail-agent mb-5">
         <div class="container">
             <div class="text-center">
                 <h4>Paket Wisata</h4>
             </div>
         </div>
     </div>

     <div class="m-paket">
         <div class="container">
             <div class="text-center" style=""><span class="judul-paket"></span>
             </div>
             <div class="row">
                 <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-4" id="sidebar">
                     <div class="box_detail booking">
                         <div class="price">
                             <span><?php echo e($item->price); ?><small>person</small></span>
                         </div>
                         <div class="paket">
                             <span><?php echo e($item->place); ?></span>
                             <p>Include Fasilities :</p>
                             <div class="row">
                                <?php echo $item->facilities; ?>

                                 <small>Untuk informasi pemesanan paket Agent Tour silahkan hubungi kontak social
                                     media dibawah ini.</small>
                             </div>
                        </div>
                        <button class="btn btn-danger btn-block mt-4">Pilih</button>
                     </div>
                 </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
         </div>
     </div>
     </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    
<script>
    $('.row>ul, .col-lg-12>ul').addClass("bullets");
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BINUS\Semester 5\web programming\laravel-project\travel\resources\views/frontend/pages/agent.blade.php ENDPATH**/ ?>