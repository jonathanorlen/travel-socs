
      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2018 <div class="bullet"></div> Design By <a href="https://nauval.in/">Muhamad Nauval Azhar</a>
        </div>
        <div class="footer-right">
        </div>
      </footer><?php /**PATH E:\BINUS\Semester 5\web programming\laravel-project\travel\resources\views/backend/includes/footer.blade.php ENDPATH**/ ?>