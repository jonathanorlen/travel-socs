 <!-- BASE CSS -->
 <link href="<?php echo e(url('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(url('frontend/css/style2.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(url('frontend/css/vendors.css')); ?>" rel="stylesheet">

 <!-- YOUR CUSTOM CSS -->
 <link href="<?php echo e(url('frontend/css/custom.css')); ?>" rel="stylesheet"><?php /**PATH E:\BINUS\Semester 5\web programming\laravel-project\travel\resources\views/frontend/includes/styles.blade.php ENDPATH**/ ?>