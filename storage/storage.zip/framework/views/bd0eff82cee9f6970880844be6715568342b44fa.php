<header class="header menu_fixed">
     <div id="preloader">
         <div data-loader="circle-side"></div>
     </div>
     <!-- /Page Preload -->
     <div id="logo">
         <a href="index.html">
             <img src="img/logo.svg" width="150" height="36" alt="" class="logo_normal">
             <img src="img/logo_sticky.svg" width="150" height="36" alt="" class="logo_sticky">
         </a>
     </div>
     <!-- /top_menu -->
     <a href="#menu" class="btn_mobile">
         <div class="hamburger hamburger--spin" id="hamburger">
             <div class="hamburger-box">
                 <div class="hamburger-inner"></div>
             </div>
         </div>
     </a>
     <nav id="menu" class="main-menu">
         <ul>
             <li><span><a href="index.html">Home</a></span></li>
             <li><span><a href="">Tempat Wisata</a></span>
                 <li><span><a href="detail-agent.html">Agent</a></span></li>
                 <li><span><a href="adventure.html">Adventure</a></span></li>
         </ul>
     </nav>
 </header>
 <!-- /header --><?php /**PATH E:\BINUS\Semester 5\web programming\laravel-project\travel\resources\views/frontend/includes/header.blade.php ENDPATH**/ ?>