<!-- General JS Scripts -->
  <script src="<?php echo e(url('assets/modules/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/modules/popper.js')); ?>"></script>
  <script src="<?php echo e(url('assets/modules/tooltip.js')); ?>"></script>
  <script src="<?php echo e(url('assets/modules/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/modules/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/modules/moment.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/stisla.js')); ?>"></script>
  
  <!-- JS Libraies -->
  <script src="<?php echo e(url('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
  <script src="<?php echo e(url('assets/modules/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js')); ?>"></script>

  <!-- Page Specific JS File -->
  <script src="<?php echo e(url('assets/js/page/forms-advanced-forms.js')); ?>"></script>
  
  <!-- Template JS File -->
  <script src="<?php echo e(url('assets/js/scripts.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/custom.js')); ?>"></script><?php /**PATH E:\BINUS\Semester 5\web programming\laravel-project\travel\resources\views/backend/includes/scripts.blade.php ENDPATH**/ ?>