<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\City;
use App\Models\Package;
use App\Models\Agent;
use Validator;

class FrontController extends Controller
{   
    public function rules($id = false){
        return [
            'name' => 'required',
            'lon' => 'required',
            'lat' => 'required',
        ];
    }
    public function index() {
        $data['citys'] = City::get();
        return view('frontend.pages.index', $data);
    }

    public function agent($id) {
        $data['data'] = Agent::find($id);
        $data['packages'] = Package::where('agent_id',$id)->get();
        return view('frontend.pages.agent', $data);
    }

    public function package($id) {
        $data['data'] = Package::find($id);
        $data['agent'] = Agent::find($data['data']->agent_id);
        return view('frontend.pages.package', $data);
    }
    
    public function form(City $city = null) {
        $data['data'] = $city;
        return view('backend.pages.city-form', $data);
    }

    public function store(Request $request, City $city = null) {
        $data = $this->validate($request, $this->rules());
        if($city == null){
            City::create($data);
            $message = $request->name.' City Created';
        }else {
            $city->update($data);
            $message = $request->name.' City Update';

        }

        $data['data'] = $city;
        return redirect()->route('city')->withSuccess($message);
    }

    public function destroy(City $city)
    {   
        try{
            $city->delete();
            return redirect()->back()->withSuccess($city->name.' City Deleted');
        }catch(Exception $e) {
            return redirect()->back()->withError($e);
        }
    }
}
